package Server;

public class Methods {
    public  double addition (double num1, double num2){

        return (num1+num2);

    }

}
